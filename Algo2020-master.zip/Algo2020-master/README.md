# Algo2020
Fake News Validator
